package qa.utils.classPackage.config;

public class Config
{

}