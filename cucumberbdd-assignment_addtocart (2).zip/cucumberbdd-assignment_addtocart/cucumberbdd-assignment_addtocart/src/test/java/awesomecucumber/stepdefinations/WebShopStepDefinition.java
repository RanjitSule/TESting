package awesomecucumber.stepdefinations;

//import awesomecucumber.constants.EndPoint;
import awesomecucumber.context.TestContext;
import awesomecucumber.pages.PageFactoryManager;
import awesomecucumber.pages.DemoWeb;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WebShopStepDefinition {

    private final DemoWeb demoWeb;
    private final TestContext context;

    public WebShopStepDefinition(TestContext context){
        this.context = context;
        demoWeb = PageFactoryManager.getDemoWeb(context.driver);
    }
    @Given("i am an existing user")
    public void iAmAnExistingUser() {

    }

    @When("i open browser to {string}")
    public void iOpenBrowserToWwwSaucedemoCom(String Url) {
//        storePage.load(EndPoint.STORE.url);
        demoWeb.load1(Url);
    }

    @And("fill correct username as {string} and password as {string}")
    public void fillCorrectUsernameAsAndPasswordAs(String arg0, String arg1) throws InterruptedException {
        demoWeb.UsernamePass("standard_user","secret_sauce");
    }

    @And("press login button")
    public void pressLoginButton() {
        demoWeb.verify();

    }

    @Then("i see my application dashboard")
    public void iSeeMyApplicationDashboard() {
        demoWeb.multipleElement();
    }
}
