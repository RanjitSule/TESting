package awesomecucumber.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

import static org.junit.Assert.assertEquals;

public class DemoWeb extends BasePage {

    public DemoWeb(WebDriver driver) {
        super(driver);
    }
    public void UsernamePass(String Username, String Pass) throws InterruptedException {
        driver.findElement(By.id("user-name")).sendKeys(Username);
        Thread.sleep(3000);
        driver.findElement(By.id("password")).sendKeys(Pass);
        Thread.sleep(3000);
        driver.findElement(By.id("login-button")).click();
        Thread.sleep(3000);
    }

    public void verify(){
        String ExpectedTitle ="Swag Labs";
        String ActualText= driver.findElement(By.xpath("//div[@class='app_logo']")).getText();
        assertEquals(ExpectedTitle,ActualText);
    }
    //Ranjit Sule
    //Description : This method returns all multiple item present in the webpage
    public List<WebElement> multipleElement() {
        List<WebElement> multipleElementt = null;
        try {
             multipleElementt = driver.findElements(By.xpath("//button[@class='btn btn_primary btn_small btn_inventory ']"));
            for(int r=0;r<multipleElementt.size();r++) {
                multipleElementt.get(r).click();
            }
        } catch (Exception e) {
            System.out.println(" Invalid property type ");
        }
        return multipleElementt;
    }
}
