package com.org.qa.pages.common;

import com.org.qa.utils.DriverUtil;

import com.org.qa.utils.FileUtil;
import com.org.qa.utils.constants.Constants;
import io.qameta.allure.Allure;
import io.qameta.allure.model.Status;





import org.json.simple.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;


import java.io.IOException;
import java.time.Duration;


import java.util.Iterator;
import java.util.List;
import java.util.function.Function;



import java.util.*;
import java.util.NoSuchElementException;
import org.openqa.selenium.support.ui.Select;



public class CommonPage extends DriverUtil{
    static WebDriverWait ExplicitWait;
    static WebElement Webelement = null;
    static String PropertyType = null;
    static String PropertyValue = null;
    static WebDriver driver =getDriver();
    public static JavascriptExecutor javaScriptDriver;
    static String userID;
    static String password;
    static String applicationURL;
    static List<WebElement> webElements = null;
    public static JavascriptExecutor _js;

    //Method Name: Launch
    //Description: This method launches the application url
    public static void Launch(String url){
      driver.get(url);
      driver.manage().window().maximize();
    }

    //Method Name : GetValue
    //Description : This method is used to get value from the property file
    public static String GetValue(String WebElement) throws IOException {
        String ObjectRepositoryValue=null;
        try {
            ObjectRepositoryValue = getObjectRepositoryProperty(WebElement);
        }
        catch(Exception e){
            System.out.println("unable to get the value from properties file");
        }
        return ObjectRepositoryValue;
    }

    //Method Name : GetWebElement
    //Description : This method is used to locate the web element in the application
     public static WebElement GetWebElement(String ObjectRepositoryValue ){
        try{
         String[] Property= GetValue(ObjectRepositoryValue).split(":=");
         PropertyType = Property[0];
         PropertyValue = Property[1];
           if (PropertyType.equalsIgnoreCase("id")) {
               Webelement = driver.findElement(By.id(PropertyValue));
           } else if (PropertyType.equalsIgnoreCase("name")) {
               Webelement = driver.findElement(By.name(PropertyValue));
           } else if (PropertyType.equalsIgnoreCase("xpath")) {
               Webelement = driver.findElement(By.xpath(PropertyValue));
           } else if (PropertyType.equalsIgnoreCase("linktext")) {
               Webelement = driver.findElement(By.linkText(PropertyValue));
           } else if (PropertyType.equalsIgnoreCase("cssselector")) {
               Webelement = driver.findElement(By.cssSelector(PropertyValue));
           } else if (PropertyType.equalsIgnoreCase("partiallinktext")) {
               Webelement = driver.findElement(By.partialLinkText(PropertyValue));
           } else if (PropertyType.equalsIgnoreCase("classname")) {
               Webelement = driver.findElement(By.className(PropertyValue));
           } else {
             System.out.println(" Invalid property type ");
           }
       }
        catch(Exception e){
            System.out.println("Unable to find the web element in object repository , "+ObjectRepositoryValue);
        }
        return Webelement;
     }

     //Method Name : TableCoulmns
     //Description : This method returns all columns of the table present in the webpage
     public static List<WebElement> TableCoulmns(String element) {
         List<WebElement> Columns = null;
         try {
             Columns = driver.findElements(GetElementForWait(element));
         } catch (Exception e) {
             System.out.println(" Invalid property type ");
         }
         return Columns;
     }

    //Method Name : TableRows
    //Description : This method returns all rows of the table present in the webpage
    public static List<WebElement> TableRows(String element) {
        List<WebElement> Rows = null;
        try {
            Rows = driver.findElements(GetElementForWait(element));
        } catch (Exception e) {
            System.out.println(" Invalid property type ");
        }
        return Rows;
    }

     //Method Name : WebClick
     //Description : This method is used to click on the specified web element
     public static void WebClick(String SpecificElement){
        try {
            WaitForPresenceOfElementLocated(SpecificElement);
            GetWebElement(SpecificElement).click();
        }
        catch(Exception e){
            System.out.println("Element Click Intercepted Exception");
        }
     }

     //Method Name : WebSend
     //Description : This is method is used for sending the text
     public static void WebSend(String Field,String TextTobeSend){
        try {
            GetWebElement(Field).click();
            Wait2();
            //Enters the Text
            GetWebElement(Field).sendKeys(TextTobeSend);
        }
        catch(Exception e){
            System.out.println("Failed to enter the data");
        }
     }

     //Method Name : WebGetText
     //Description : This method returns the text of the web element
    public static String WebGetText(String element){
        String WebText=null;
        try{
            WebText=GetWebElement(element).getText();
        }
        catch(Exception e){
            System.out.println("Failed to get the text");
        }
        return WebText;
    }

    public static By GetElementForWait(String ObjectRepositoryValue) {
        By WaitLocator = null;
        try {
            String[] Property = GetValue(ObjectRepositoryValue).split(":=");
            PropertyType = Property[0];
            PropertyValue = Property[1];
            if (PropertyType.equalsIgnoreCase("id")) {
                WaitLocator = By.id(PropertyValue);
            } else if (PropertyType.equalsIgnoreCase("name")) {
                WaitLocator = By.name(PropertyValue);
            } else if (PropertyType.equalsIgnoreCase("xpath")) {
                WaitLocator = By.xpath(PropertyValue);
            } else if (PropertyType.equalsIgnoreCase("linktext")) {
                WaitLocator = By.linkText(PropertyValue);
            } else if (PropertyType.equalsIgnoreCase("cssselector")) {
                WaitLocator = By.cssSelector(PropertyValue);
            } else if (PropertyType.equalsIgnoreCase("partiallinktext")) {
                WaitLocator = By.partialLinkText(PropertyValue);
            } else if (PropertyType.equalsIgnoreCase("classname")) {
                WaitLocator = By.className(PropertyValue);
            } else {
                System.out.println(" Invalid ");
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return WaitLocator;
    }

    //Method Name :WaitForPresenceOfElementLocated
    //Description :This method is used to explicitly wait for presence of element located
    public static boolean WaitForPresenceOfElementLocated(String element){
        try {
            ExplicitWait = new WebDriverWait(driver, Duration.ofSeconds(100));
            ExplicitWait.until(ExpectedConditions.presenceOfElementLocated(GetElementForWait(element)));
            return true;
        }
        catch (Exception e){
            return false;
        }
    }

    //Method Name: WaitForElementTovisibile
    //Description: This method is used to explicitly wait for element to be visible
    public static boolean WaitForElementTovisibile(String element){
        try{
            ExplicitWait = new WebDriverWait(driver, Duration.ofSeconds(10));
            ExplicitWait.until(ExpectedConditions.visibilityOfElementLocated(GetElementForWait(element)));
            return true;
        }
        catch (Exception e){
            return false;
        }
    }

    //Method Name: Scroll
    //Description: This method scroll the web page until the web element is visible
    public static void Scroll(String scrollelement){
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();",GetWebElement(scrollelement));
    }

    //Method Name : MouseHover
    //Description : This method moves the mouse control to the specific element
    public static void MouseHover(String ActionElement){
        Actions action=new Actions(driver);
        action.moveToElement(GetWebElement(ActionElement)).build().perform();

    }

    //Method Name: GeneratedSourcingBundleID
    //Description: This methos returns the dynamically generated Sourcing Bundle ID
    public static String GeneratedSourcingBundleID(String element) {
        String[] alertMsg = null;
        try {
            WaitForElementTovisibile(element);
            alertMsg = WebGetText("IDAlertMsg").split(" ");
            //System.out.println("SB-ID:"+alertMsg[3]);
        } catch (Exception e) {
            System.out.println("Element Not present Exception");
        }
        return alertMsg[3];
    }

    //Method Name : Refresh
    //Description : This method refreshes the web page
    public static void Refresh(){
        driver.navigate().refresh();
    }

    //Method Name : CloseBrowser
    //Description : This method closes all the browsers
    public static void CloseBrowser(){
        try {
//            driver.close();
            driver.quit();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to quit the browser");

        }

    }

    //Method Name : Sleep Wait
    //Description : This method is for Thread sleep
    public static void Wait1() throws InterruptedException {
        Thread.sleep(1000);
    }

    //Method Name : Sleep Wait
    //Description : This method is for Thread sleep
    public static void Wait2() throws InterruptedException {
        Thread.sleep(2000);
    }

    /* Application : Common Function
     * Method Name : highLightElement
     * Description : This method is used to highlight an element on screen
     * Parameters  : objName
     * Author      : Aastha Uppal
     * Date        : 10/18/2022
     */
    public static void highLightElement(String objName){

        WebElement lWebElement;
        lWebElement = GetWebElement(objName);
        javaScriptDriver = (JavascriptExecutor) driver;

        javaScriptDriver.executeScript("arguments[0].setAttribute('style','border: solid 2px red')", lWebElement);

        try
        {
            Thread.sleep(1000);
        }
        catch (InterruptedException e) {

            System.out.println(e.getMessage());
        }
        javaScriptDriver.executeScript("arguments[0].setAttribute('style','border: solid 2px white')", lWebElement);

    }

    /* Application : Common Function
     * Method Name : loginApplication
     * Description : This method is used to login to the application
     * Parameters  : fileName, scrNo
     * Author      : Aastha Uppal
     * Date        : 10/18/2022
     */
    public static void loginApplication(String fileName, String scrNo)
    {
        try{
            JSONObject data = FileUtil.getDataFromJsonFile(fileName,scrNo);
            applicationURL=(String) data.get("applicationURL");
            userID= (String) data.get("userID");
            password= (String) data.get("password");
            Allure.step("Navigating to the application URL: "+applicationURL);
            Launch (applicationURL);
            System.out.println(applicationURL);
            Allure.step("Entering userid and password: "+userID);
            //enter user id and password
            WaitForPresenceOfElementLocated("LoginID");
            WebSend("LoginID", userID);
            WebClick("LogNext");
            WaitForPresenceOfElementLocated("Login Password");
            WebSend("LoginPassword", password);
            WebClick("LoginButton");
            System.out.println("Logging in to application");
            Allure.step("Logging in to application");
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /* Application : Common Function
     * Method Name : GetWebElements
     * Description : This method is used to find array of elements with obj repository locator
     * Parameters  : ObjectRepositoryValue
     * Author      : Aastha Uppal
     * Date        : 10/19/2022
     */
    public static WebElement GetWebElements(String ObjectRepositoryValue ){
        try{
            String[] Property= GetValue(ObjectRepositoryValue).split(":=");
            PropertyType = Property[0];
            PropertyValue = Property[1];
            if (PropertyType.equalsIgnoreCase("id")) {
                webElements = driver.findElements(By.id(PropertyValue));
            } else if (PropertyType.equalsIgnoreCase("name")) {
                webElements = driver.findElements(By.name(PropertyValue));
            } else if (PropertyType.equalsIgnoreCase("xpath")) {
                webElements = driver.findElements(By.xpath(PropertyValue));
            } else if (PropertyType.equalsIgnoreCase("linktext")) {
                webElements = driver.findElements(By.linkText(PropertyValue));
            } else if (PropertyType.equalsIgnoreCase("cssselector")) {
                webElements = driver.findElements(By.cssSelector(PropertyValue));
            } else if (PropertyType.equalsIgnoreCase("partiallinktext")) {
                webElements = driver.findElements(By.partialLinkText(PropertyValue));
            } else if (PropertyType.equalsIgnoreCase("classname")) {
                webElements = driver.findElements(By.className(PropertyValue));
            } else {
                System.out.println(" Invalid property type ");
            }
        }
        catch(Exception e){
            System.out.println("Unable to find the web element in object repository , "+ObjectRepositoryValue);
        }
        return (WebElement) webElements;
    }

    /* Application : Common Function
     * Method Name : setTextToClipBoard
     * Description : This method is used to set the values in the clipboard which can be pasted as per the requirement
     * Parameters  : aString
     * Author      : Aastha Uppal
     * Date        : 10/20/2022
     */
    public static void setTextToClipBoard(String aString){
        StringSelection stringSelection = new StringSelection(aString);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
    }

    /* Application : Common Function
     * Method Name : setTextToClipBoard
     * Description : This method is used to set the values in the clipboard which can be pasted as per the requirement
     * Parameters  : aString
     * Author      : Aastha Uppal
     * Date        : 10/20/2022
     */
    public static void logOutApplication(){
        WebClick("logoutDD");
        WebClick("logOutBtn");
        driver.close();
    }

     public static SearchContext getShadowRoot(String querySelectorHost, boolean isOpen){
        JavascriptExecutor js=(JavascriptExecutor)driver;
     if(isOpen){
         return(SearchContext) (js.executeScript("return document.querySelector(\""+querySelectorHost+"\").shadowRoot"));
     }

         return (WebElement) webElements;
     }

    /* Application: Common Function
    * Method Name: webExplicit Wait
    * Description: This method is used to explicitly wait for an element to be clickable
    * Parameters: logicalName OfObject, timeInSeconds
    * Author : Aastha Uppal
    * Date : 11/02/2022
    */
    public static boolean webExplicitWait(String logicalNameOfObject, int timeInSeconds) {

        try {
            WebElement lWebElement = null;
            lWebElement = GetWebElement(logicalNameOfObject);
            //javaScriptDriver.executeScript("arguments[0].scrollIntoView(true);", IWebElement)

            (new WebDriverWait(driver,Duration.ofSeconds(timeInSeconds))).until(ExpectedConditions.elementToBeClickable(lWebElement));
            return true;
        }
        catch (Exception e) {
            return false;
        }
    }
    /* Application: Common Function
    * Method Name: waitForElement To Visibile
    * Description: This method is used to explicitly wait for an element to be visible
    * Parameters: element, timeInSeconds
    * Author : Aastha Uppal
    * Date : 11/02/2022
    */
    public static boolean waitForElementToVisibile (WebElement element, int timeInSeconds) {
        try {
            for(int i=0;i<timeInSeconds;i++) {
                try{
                    WebElement lWebElement = null;
                    lWebElement = element;
                    (new WebDriverWait(driver, Duration.ofSeconds(timeInSeconds))).until (ExpectedConditions.visibilityOf(lWebElement));
                    return true;
                }
                catch(Exception e){
                    return false;
                }
            }
        }catch(Exception e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    public static boolean webExplicitWaitXpath(String xpath, int timeInSeconds){

        try{
            WebElement lWebElement = null;
            //javaScriptDriver.executeScript("arguments[0].scrollIntoView(true);",
            lWebElement = driver.findElement(By.xpath(xpath));
            (new WebDriverWait(driver,Duration.ofSeconds(timeInSeconds ))).until (ExpectedConditions.elementToBeClickable(lWebElement));
            return true;
        }
        catch(Exception e){
            return false;
        }
    }
    public static boolean webExplicitWaitXpathOfObject(String xpath, int timeInSeconds){

        try{
            WebElement lWebElement = null;

            lWebElement = driver.findElement(By.xpath(xpath));
            (new WebDriverWait(driver,Duration.ofSeconds(timeInSeconds) )).until (ExpectedConditions.elementToBeClickable (lWebElement));
            return true;
        }
        catch(Exception e){
            return false;
        }
    }
    public static boolean webExplicitWaitForVisible(String logicalNameOfObject, int timeInSeconds){
        try{
            WebElement lWebElement = null;
            lWebElement = GetWebElement(logicalNameOfObject);
            (new WebDriverWait(driver, Duration.ofSeconds(timeInSeconds))).until (ExpectedConditions.visibilityOf(lWebElement));
            return true;
        }
        catch (NullPointerException e) {

        }
        catch (Exception e)
        {

        }
        return false;
    }
	public static void clickWebElement(String xpath1) throws InterruptedException
	{
		try {
			Actions action = new Actions(driver);
			action.moveToElement(driver.findElement(By.xpath(xpath1))).click().build().perform();
		} catch (Exception e) {
			System.out.println("Not able to click on webelement:" + xpath1);
			e.printStackTrace();
		}
	}

	public static boolean webNotExists(final String xpath) {
		try {
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);

			wait.pollingEvery(Duration.ofMillis(500));
			wait.withTimeout(Duration.ofSeconds(2));
			// wait.pollingEvery(500, Time Unit. MILLISECONDS);
			// wait.withTimeout(2, TimeUnit.SECONDS);
			wait.ignoring(NoSuchElementException.class);

			WebElement element = wait.until(new Function<WebDriver, WebElement>() {

				public WebElement apply(WebDriver argo)
				{
					WebElement ele = argo.findElement(By.xpath(xpath));
					if (ele.isDisplayed())
					{
						return ele;
					} else
					{
						return null;
					}
				}
			});
			if (element != null) {
				return false;
			} else {
				return true;
			}
		}
		catch (Exception e) {
			return true;
		}
	}
	public static void webClick1 (WebElement objName) throws IOException{

		try {
			Actions act=new Actions (driver);
			act.moveToElement(objName).click().perform();


		} catch (Exception e) {
			Allure.step("Web Element [" + objName + "] NOT FOUND on UI", Status. FAILED);


		}

	}
	/**
	 * This method is used to get current window handle
	 *
	 * @return returns current window handle
	 * @author Nagaraj Jayagondra
	 */
	public static String getCurrentWindowHandle(){
		String winhandle = null;
		try{
			winhandle = driver.getWindowHandle();
		}catch(Exception e){
        // ReportUtil.reporterEvent("fail", "Unable to retrive current window handle");
		}
		return winhandle;
	}












































   public static void validateElementExistence(String objName, String fieldName){
        String field_Text=fieldName;
        try{
            WebElement lWebElement;
            lWebElement=GetWebElement(objName);
            if(GetWebElement(objName).isDisplayed()){
				Allure.step(field_Text +"is displayed on the UI ", Status.PASSED);
			} else
				Allure.step(field_Text + "is displayed on the UI ", Status.FAILED);
		} catch (Exception e) {
			Allure.step(field_Text + " is not displayed on the UI", Status.FAILED);
			e.printStackTrace();
		}
   }

	public static String getWebElementText(String logicalName)
	{
		if (webExists(GetWebElement(logicalName)))
		{
			return GetWebElement (logicalName).getText();
		}
		else
			return null;
	}
	public static boolean webExists(WebElement element){
		try{
			return element.isDisplayed();
		}
		catch(Exception e){
			return false;
		}
	}





































































	/**
	 * This method is used to get run time value from the AUT
	 *
	 * @param objectLogicalName Logical name of the object in OR
	 * @param attributeName Name of the attribute to be captured
	 * @return returns the captured value
	 */
	public static String webGetAttribute(String objectLogicalName, String attributeName){
		String attributeValue = null;
		try{
			WebElement IwebElement = GetWebElement(objectLogicalName);
			attributeValue = IwebElement.getAttribute(attributeName);
		}catch(Exception e){
			e.printStackTrace();
		}
		return attributeValue;
	}
	public static boolean waitForElementTovisibile (WebElement element, int timeInSeconds) {
		try {
			for (int i = 0; i < timeInSeconds; i++) {
				try {
					WebElement lWebElement = null;
					lWebElement = element;
					(new WebDriverWait(driver, Duration.ofSeconds(timeInSeconds))).until(ExpectedConditions.visibilityOf(lWebElement));
					return true;
				}
				catch (Exception e) {
					return false;

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}


	public static void highLighterMethod(WebElement element){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
	}

	public static String webElementGetAttribute(String locatorPath, String attributeName) {
		WebElement webEle = null;
		try {
			String[] parts = locatorPath.split(":=");
			String propType = parts[0];
			String propActVal = parts[1];
			if (propType.equalsIgnoreCase("id")) {
				webEle = driver.findElement(By.id(propActVal));
			} else if (propType.equalsIgnoreCase("name")) {
				webEle = driver.findElement(By.name(propActVal));
			} else if (propType.equalsIgnoreCase("xpath")) {
				webEle = driver.findElement(By.xpath(propActVal));
			} else if (propType.equalsIgnoreCase("linktext")) {
				webEle = driver.findElement(By.linkText(propActVal));
			} else if (propType.equalsIgnoreCase("cssselector")) {
				webEle = driver.findElement(By.cssSelector(propActVal));
			} else if (propType.equalsIgnoreCase("partiallinktext")) {
				webEle = driver.findElement(By.partialLinkText(propActVal));
			} else if (propType.equalsIgnoreCase("classname")) {
				webEle = driver.findElement(By.className(propActVal));
			} else {
				Allure.step("Invalid Locator or Locator value", Status.FAILED);
			}
		} catch (Exception e) {
			Allure.step("Locator not found: " + locatorPath, Status.FAILED);
		}
		return webEle.getAttribute(attributeName);
	}


	public static void VerifyMessage(String message, String xpath, String Type) throws Exception {
		try {
			if (webExplicitWaitXpath(xpath, 1)) {
				Allure.step(Type + " message " + message + " displayed", Status.PASSED);
			} else {
				Allure.step(Type + " message " + message + " not displayed", Status.FAILED);
				Assert.fail();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			Allure.step("message " + message + " not displayed", Status.FAILED);
			Assert.fail();
		}
	}

	public static void UploadFile(String FileName, int wait) throws Exception {
		try {
			//Upload the document in "upload photo Evidence" Title should be entered and Image should be uploaded either by drag and drop or by selecting the file
			if (CommonPage.webExplicitWaitXpath("//div[contains(text(), 'Drag and drop your file or click anywhere to select.')]/preceding-sibling::*[contains(@class,'MuiSvgIcon-root')]", 1)) {
				CommonPage.webClick1(driver.findElement(By.xpath("//div[contains (text(), 'Drag and drop your file or click anywhere to select.')]/preceding-sibling::*[contains(@class,'MuiSvgicon- root')]")));
				Allure.step(" User able to click on select icon of Uploading the document ", Status. PASSED);
			}else{
				Allure.step("User failed to click on select icon of Uploading the document", Status.FAILED);
				Assert.fail();
			}
			Thread.sleep(5000);

			//click on folder button
			Thread.sleep(2000);
			setTextToClipBoard(System.getProperty("user.dir")+Constants.testArtifactsPath+"CERTUS\\"+FileName);
			Thread.sleep(2000);
			Robot robot = new Robot();
			robot.keyPress (KeyEvent.VK_CONTROL);
			robot.keyPress (KeyEvent.VK_V);
			robot.keyRelease (KeyEvent.VK_CONTROL);
			robot.keyRelease (KeyEvent.VK_V);
			Thread.sleep(2000);
			robot.keyPress (KeyEvent.VK_ENTER);
			robot.keyRelease (KeyEvent.VK_ENTER);
			Thread.sleep(2000);
			Allure.step("User able to provide path for uploading file "+FileName, Status.PASSED);
			Thread.sleep(wait);

		}catch(Exception e) {
			Allure.step("User not able to Upload file", Status.FAILED);
			Assert.fail();
			e.printStackTrace();
		}
	}

	public static void webSetTextObj(WebElement objName, String strTextToSend) throws IOException {
		WebElement lwebElement = null;
		try {
			lwebElement = (objName);
			//strTextToSend = ExcelUtil.getDataFromExcel (onlyTestCaseName, strTextToSend);

			lwebElement.clear();
			Thread.sleep(1000);

			lwebElement.sendKeys(strTextToSend);
			//ReportUtil.reporterEvent("info", "Text [" + strTextToSend + "] entered in the web element [" + objName + "]");
		} catch (Exception e) {
		}

	}

	public static boolean WaitForElementToBeClickable(String element) {
		try {
			ExplicitWait = new WebDriverWait(driver, Duration.ofSeconds(100));
			ExplicitWait.until(ExpectedConditions.elementToBeClickable(GetElementForWait(element)));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static void scrollIntoWebElement_new(WebElement objectName) {
		try {
			javaScriptDriver.executeScript("arguments[0].scrollIntoView(true);", objectName);
		} catch (Exception e) {
		}
	}

	public static void clickUsingJS(WebElement objectLogicalName) {

		try {
			javaScriptDriver.executeScript("arguments[0].click();", objectLogicalName);


		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void webSetText(String objName, String strTextToSend) throws IOException {
		WebElement lwebElement = null;
		try {
			lwebElement = GetWebElement(objName);

			lwebElement.sendKeys(strTextToSend);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void webSet(String objName, String strTextToSend) {
		WebElement lwebElement= null;
		try {
			lwebElement =GetWebElement(objName);
			lwebElement.clear();
			lwebElement.sendKeys(strTextToSend);

		} catch (Exception e) {

		}
	}
	public static void webSetObj(WebElement objName, String strTextToSend) {
		WebElement lwebElement = null;
		try {
			lwebElement =(objName);
			System.out.println(strTextToSend);
			lwebElement.clear();
			lwebElement.sendKeys(strTextToSend);
			Allure.step("Text [" + strTextToSend + "] entered in the web element [" + objName + "]", Status. PASSED);
		} catch (Exception e) {
			Allure.step("Text [" + strTextToSend + "] not entered in the web element [" + objName + "]", Status.FAILED);
			Assert.fail();
		}
	}
	public static void selectFromList(String eleName, String visibleText) {
		try {
			Thread.sleep(1000);
			Select select = new Select(driver.findElement(By.xpath("//select[contains(@name,'" + eleName + "')]")));
			select.selectByVisibleText(visibleText);

		} catch (Exception e) {
			e.printStackTrace();
			Allure.step("Select:" + visibleText + " failed to select", Status.FAILED);


		}
	}

	public static void rightClick(WebElement elementName) throws IOException {

		try {
			Actions action = new Actions (driver);
		    action.contextClick(elementName).perform();

		} catch (Exception e) {
		}
	}
	public static void waitTillPageIsLoadedFully() {
		try {


			Object state = ((JavascriptExecutor) driver).executeScript("return document.readyState");
			int timeout = 0;
			while (state.toString() != "complete") {
				try {
					Thread.sleep(2000);
					timeout = timeout + 1;
					if (timeout > 20) {
						break;
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void doubleClick(WebElement elementName) throws IOException {
		try {
			Actions action = new Actions(driver);
			action.doubleClick(elementName).build().perform();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void webSetAttribute(WebElement objectName, String attribute, String value) {
		try {
			String scriptSetAttrValue = "arguments[0].setAttribute(arguments[1],arguments[2])";

			javaScriptDriver.executeScript(scriptSetAttrValue, objectName, attribute, value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void WebSetTextDOM(WebElement objectName, String value) {
		try {

			String scriptSetAttrValue = "arguments[0].setAttribute('value', '" + value + "');";

			javaScriptDriver.executeScript(scriptSetAttrValue, objectName);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String getWebElementTextObj(WebElement object) {
		if (webExists(object)) {
			return object.getText();
		} else
			return null;
	}
	public static HashMap<String, String> getWindowTitle() {
		try {
			String parentWnd = driver.getWindowHandle();

			Set<String> wnd = driver.getWindowHandles();

			Iterator<String> itr = wnd.iterator();
			String childWnd = null;
			while (itr.hasNext()) {
				childWnd = itr.next();
			}
			HashMap<String, String> hm = new HashMap<String, String>();
			hm.put("Parent", parentWnd);
			hm.put("Child", childWnd);

			return hm;
		} catch (Exception e) {
			e.printStackTrace();
			return null;

		}
	}


	public static void acceptAlert() {
		try {
			Alert alert = driver.switchTo().alert();
			alert.accept();
			Allure.step("OK/Accept button should be clicked, OK/Accept button is clicked", Status.PASSED);
		}catch(Exception e){
				Allure.step("OK/Accept button should be clicked, Failed to select OK/Accept button", Status.FAILED);
				e.printStackTrace();
			}
		}
	public static boolean isExist(String object_locator) {
		try {
			GetWebElement(object_locator).isDisplayed();
			return true;
		}catch (Exception e) {
			return false;

		}
	}
	public static void switchToFrame (String frameElementObj){
		try{
			WaitForElementTovisibile (frameElementObj);
			driver.switchTo().frame(GetWebElement (frameElementObj));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void switchBackFromFrame(){
		try{
			driver.switchTo().defaultContent();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void Wait3() throws InterruptedException {
		Thread.sleep(3000);
	}
	public static void switchbackWindow() {
		try {
			String curr_win=driver.getWindowHandle();
			Set<String> win_set=new HashSet<String>();
			win_set=driver.getWindowHandles();
			for(String win:win_set) {
				if(curr_win.equals(win)) {
					driver.switchTo().window(curr_win);
					driver.close();
				}
			}
			win_set = driver.getWindowHandles();
			for(String win:win_set) {
				driver.switchTo().window(win);
			}

		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static void switchWindow() {
		try {
			String main_win=driver.getWindowHandle();
			Set<String> win_set= new HashSet<String>();
			win_set=driver.getWindowHandles();
			for(String win:win_set) {
				if(!win.equals(main_win)) {
					driver.switchTo().window(win);
					System.out.println("Window : "+driver.getWindowHandle());
					driver.manage().window().maximize();

				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static void enterText(String object_locator, Keys keyboardKey) {
		try{
			GetWebElement(object_locator).sendKeys(keyboardKey);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static boolean waitForElementTovisible(String Object_locator, int timeinSeconds) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeinSeconds));
			wait.until(ExpectedConditions.visibilityOf(GetWebElement(Object_locator)));
			_js.executeScript("arguments[0].setAttribute('style', 'border: 2px solid red;');", GetWebElement(Object_locator));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static boolean webVerifyIsElementEnabled(WebElement webElement) {
		try {
			webElement.isEnabled();
			Allure.step(webElement + " is enabled", Status.PASSED);
			return true;
		} catch (Exception e) {
			Allure.step(webElement + " is disabled", Status.SKIPPED);
			return false;
		}
	}
}



