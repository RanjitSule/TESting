package com.org.qa.utils;
import com.org.qa.pages.common.CommonPage;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
//import com.org.qa.pages.common.CommonPage;

public class DemoUtils {
	public static void launchUrl(String FileName, String Scenario) throws InterruptedException {
		JSONObject Data = FileUtil.getDataFromJsonFile(FileName, Scenario);
		String url = (String) Data.get("ApplicationUrl");
		CommonPage.Launch(url);
		Thread.sleep(3000);
	}
	public static void enterLoginCredentials (String FileName, String Scenario){
		JSONObject Data = FileUtil.getDataFromJsonFile(FileName, Scenario);

		String Username = (String) Data.get("Username");
		CommonPage.WebSend("input_field_username",Username);

		String Password = (String) Data.get("Password");
		CommonPage.WebSend("input_field_PassWord",Password);
	}
	public static void homePageIsDisplayed(){
		CommonPage.validateElementExistence("home_page_product_text", "Products");
		System.out.println("Home Page is displayed");

	}
}