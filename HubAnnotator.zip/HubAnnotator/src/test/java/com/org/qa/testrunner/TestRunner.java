package com.org.qa.testrunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

import java.io.IOException;

@RunWith(Cucumber.class)
@CucumberOptions(features=("src/test/resources/features"), glue={"com.org.qa.steps"},
		tags="@TC001", plugin = { "pretty", "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"})
public class TestRunner {
	@AfterClass
	public static void writeExtentReport() throws IOException {
	}
}
