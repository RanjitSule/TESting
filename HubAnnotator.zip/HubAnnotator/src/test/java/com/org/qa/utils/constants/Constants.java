package com.org.qa.utils.constants;
import javax.mail.Folder;
import java.io.File;


public class Constants {
    public static String configPath= File.separator+"src"+File.separator+"test"+File.separator+"resources";
    public static String envPath=File.separator+"src"+File.separator+"test"+File.separator+"resource" +File.separator +"properties"+ File.separator+ "int.properties";
    public static String envPropertyPath=File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"properties"+File.separator+"environment.properties";
    public static String ReqBodyPath=File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"inputjson"+ File.separator;
    public static String SchemaPath=File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"jsonschema"+File.separator;
    public static String ObjectRepositoryPath=File.separator+"src"+File.separator+"test"+File.separator+"resources"+File.separator+"properties"+File.separator+"ObjectRepository.properties";
    public static String testArtifactsPath = configPath+File.separator+"testArtifacts"+File.separator;
    public static String testArtifactDownloadsPath=testArtifactsPath+"Downloads"+File.separator;
    public static String systemDownloadsPath="C:"+File.separator+"Users"+File.separator+System.getProperty("user.name")+File.separator+"downloads"+File.separator;
    public static String resultDocumentsPath=System.getProperty("user.dir")+testArtifactsPath+"TestResults"+File.separator;
    public static String screenshotsFolderPath=System.getProperty("user.dir")+testArtifactsPath+"Screenshots"+ File.separator;
}
