package com.org.qa.testrunner;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import org.junit.runner.RunWith;
import org.testng.annotations. DataProvider;
@RunWith(Cucumber.class)
@ CucumberOptions(features=("src/test/resources/features"),
		glue={"com.org.qa.steps"}, tags = "",
		plugin = {"pretty", "io.gameta.allure.cucumber7Jvm.AllureCucumber7Jvm"},
		monochrome = true)

public class TestNGRunner extends AbstractTestNGCucumberTests{
	@Override
	@DataProvider(parallel = false)
	public Object[][] scenarios() {return super.scenarios();}
}