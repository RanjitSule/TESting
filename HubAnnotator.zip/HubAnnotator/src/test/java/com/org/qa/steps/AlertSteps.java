package com.org.qa.steps;

import com.org.qa.pages.common.CommonPage;
import com.org.qa.utils.DemoUtils;
import com.org.qa.utils.DriverUtil;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.Alert;

import static com.org.qa.utils.DriverUtil.driver;

public class AlertSteps {

	public static String scenarioName = null;
	public static String scenarioStatus = null;
	public static Scenario scenario;

//	@Before(order=2)
//	public void initDriver(){
//		System.out.println("Open Browser");
//		driver= DriverUtil.getDriver();
//	}
//
//	@Before(order = 1)
//	public void before(Scenario scenario){
//		this.scenario=scenario;
//		scenarioName = scenario.getName();
//		System.out.println("Scenaio - "+scenario.getName());
//	}

	@Given("User open website {string} {string}")
	public void userOpenWebsite(String arg0, String arg1) throws InterruptedException {
		DemoUtils.launchUrl(arg0,arg1);
	}

	@When("User click on alert button")
	public void userClickOnAlertButton() {
		CommonPage.WebClick("alertBtn");
	}

	@Then("Validate alert window")
	public void validateAlertWindow() {
		Alert alert =driver.switchTo().alert();
		System.out.println(alert.getText());
	}

	@And("close the browser")
	public void closeTheBrowser() {
		DriverUtil.quiteDriver();
	}
}