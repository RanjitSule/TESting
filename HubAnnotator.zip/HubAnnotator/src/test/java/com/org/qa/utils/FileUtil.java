package com.org.qa.utils;
import com.google.common.io.Files;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.apache.commons.io.FileUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium. TakesScreenshot;

import java.io.*;
import java.util.Properties;

import static com.org.qa.steps.stepDemo.scenarioName;
import static com.org.qa.utils.DriverUtil.driver;
import static com.org.qa.utils.constants.Constants.resultDocumentsPath;
import static com.org.qa.utils.constants.Constants.screenshotsFolderPath;
import static java.nio.charset.StandardCharsets.UTF_8;


public class FileUtil {
private static final String jsonfilePath=System.getProperty("user.dir")+File.separator+"src"+
        File.separator+ "test"+ File.separator+ "resources"+File.separator+ "inputjson" + File.separator;
        static Properties props = new Properties();
        static FileInputStream ip=null;

        private static String propertyfilepath = System.getProperty("user.dir")+ File.separator+"src"+
                File.separator+"test"+File.separator+"resources"+File.separator+ "properties"+
                File.separator+"environment.properties";

        public static String getProperty(String property)
        {
            try{
                System.out.println("Selected Env is:" + System.getProperty("testEnv"));
                String env=System.getProperty("testEnv");
                if(env.length() >0)
                {
                    switch(env)
                    {
                        case "int":
                            propertyfilepath=System.getProperty("user.dir")+ File.separator+"src"+
                                    File.separator+"test"+File.separator+"resources"+File.separator+ "properties"+
                                    File.separator+"int.properties";
                            break;
                        case "Regression":
                            propertyfilepath=System.getProperty("user.dir")+ File.separator+"src"+
                                    File.separator+"test"+File.separator+"resources"+File.separator+ "properties"+
                                    File.separator+"regression.properties";
                            break;
                        case "test":
                            propertyfilepath=System.getProperty("user.dir")+ File.separator+"src"+
                                    File.separator+"test"+File.separator+"resources"+File.separator+ "properties"+
                                    File.separator+"test.properties";
                            break;
                    }
                }
                ip=new FileInputStream(propertyfilepath);
                props.load(ip);
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            return props.getProperty(property);
        }

        public static String readJSONFile(String fileName)
        {
            String fileData="";
            try{
                File file=new File(jsonfilePath+fileName);
                fileData=Files.toString(file,UTF_8);

            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            return fileData;
        }

        public static JSONObject getDataFromJsonFile(String FileName,String Scenario)
        {
            try{
                JSONParser parser = new JSONParser();
                JSONObject obj=(JSONObject) parser.parse(new FileReader(System.getProperty("user.dir")+ File.separator+"src"+File.separator+"test"+File.separator+ "resources"+File.separator+"jsontestdata"+File.separator+FileName+".json"));
                JSONArray arr= (JSONArray) obj.get("Scenarios");
                System.out.println("Array :" + arr.size());
                String dataId;
                for (int i=0;i<arr.size();i++)
                {
                    JSONObject data=(JSONObject) arr.get(i);
                    dataId=(String)data.get("sc_id");
                    if (dataId.equalsIgnoreCase(Scenario))
                    {
                        //System.out.println((String)data.get("loginID"));
                        //System.out.println((String)data.get("password"));
                        //System.out.println((String) data.get("url"));
                        return data;
                    }
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }

        public static void copyFile(String source, String destination){
            try{
                File src=new File(source);
                File dest=new File(destination);
                System.out.println("Source : "+source+"; Dest : "+dest);
                try{
                    FileUtils.copyFileToDirectory(src, dest);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } catch (Exception e){
                e.printStackTrace();
            }

        }


        /* Method Name : captureScreenShot
         *Description: In this function we will capture screenshots and store them in the test case folder under Screenshots
         * Parameters: description, status
         * Author: Aastha Uppal
         */

    public static void captureScreenShot(String description, String status){
        try{
            File ssDir=new File(screenshotsFolderPath);
            if(!ssDir.exists()){
                ssDir.mkdir();
            }
            String screenshot_name = System.currentTimeMillis() + "_"+ description + "_"+ status + ".png";
            //use TakeScreenshot method to capture screenshot
            TakesScreenshot screenshot = (TakesScreenshot) driver;
            //Saving the screenshot in desired location
            File source = screenshot.getScreenshotAs(OutputType.FILE);
            File destination= new File(screenshotsFolderPath+scenarioName+"\\"+ screenshot_name);
            //path to the location to save screenshot
            FileUtils.copyFile(source,destination);
            System.out.println(screenshot_name+" - Screenshot is captured");

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

     /* Method Name : updateDoc
     * Description: In this function we will consolidate all the screenshots in a word document. This will be executed after each scenario
     * Parameters: scenarioStatus
     * Author: Aastha Uppal
     */

     public static void updateDoc(String scenarioStatus) throws IOException, InvalidFormatException {
         File ssFolder = new File(screenshotsFolderPath);
         if (ssFolder.exists()) {
             System.out.println("Updating Word Document Now");
            // Create the destination file and folder structure
             File resultsDir = new File(resultDocumentsPath);
             if (!resultsDir.exists()) {
                 resultsDir.mkdir();
             }
             File destfile = new File(resultDocumentsPath + System.currentTimeMillis()+ "_"+ scenarioName + scenarioStatus + ".docx");
             destfile.getParentFile().mkdirs();
             destfile.createNewFile();

            // Create the docx object
             XWPFDocument doc = new XWPFDocument();

            // Get the source folder and list of files (includes images and
            // sub-folders)
             File srcfile = new File(screenshotsFolderPath + scenarioName + "\\");
             File[] list = srcfile.listFiles();
             System.out.println("Source folder item list " + list.length);

            // Iterate through the files in the source folder
            for (int k = 0; k <list.length; k++) {
                if (list[k].isFile()) {
                 String ssName = list[k].getName().replaceAll("\\.\\w+$", ""); //regex to remove extension -.png
                 System.out.println("File - " + ssName);
                 String[] split_ssName = ssName.split("_");
                 String description = split_ssName[1];
                 System.out.println("Description - " + description);
                 String status = split_ssName[2];
                 System.out.println("Status - " + status);

            // Create paragraph
                 XWPFParagraph p = doc.createParagraph();
                 XWPFRun r = p.createRun();

            //add screenshot description
                 r.setText("Step: " + description);
                 r.addBreak();
                 r.setText("Status: " + status);
                 r.addBreak();

            // Create fis for image
            FileInputStream fis = new FileInputStream(list[k].getPath());
            // add image using the fis
            r.addPicture(fis, XWPFDocument.PICTURE_TYPE_PNG,
                    list[k].getPath(),
                    Units.toEMU(500), Units.toEMU(250));
                fis.close();
                list[k].delete();

            } else if (list[k].isDirectory()) {
                System.out.println("Directory - " + list[k].getName());
            // If directory do nothing
            // A recursive logic can be implemented to handle the files
            // inside folders in source folder
            }
         }

            // write docx to destination file
             FileOutputStream fos = new FileOutputStream(destfile);
             doc.write(fos);
             fos.close();
             doc.close();
         }else{
             System.out.println("No Screenshot folder available");
         }
     }

}
