package com.org.qa.steps;

import com.org.qa.pages.common.CommonPage;
import com.org.qa.utils.DemoUtils;
import com.org.qa.utils.DriverUtil;
import static com.org.qa.utils.DriverUtil.driver;

import com.org.qa.utils.FileUtil;
import io.cucumber.java.Before;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.io.IOException;

public class stepDemo {

    public static String scenarioName = null;
    public static String scenarioStatus = null;
    public static Scenario scenario;

    @Before(order=2)
    public void initDriver(){
        System.out.println("Open Browser");
        driver= DriverUtil.getDriver();
    }

    @Before(order = 1)
    public void before(Scenario scenario){
        this.scenario=scenario;
        scenarioName = scenario.getName();
        System.out.println("Scenaio - "+scenario.getName());
    }

    @After(order = 1)
    public void createResultsDocument() throws IOException, org.apache.poi.openxml4j.exceptions.InvalidFormatException {
        scenarioStatus = String.valueOf(scenario.getStatus());
        FileUtil.updateDoc(scenarioStatus);
    }

    @Given("User open application {string} {string}")
    public void userOpenApplication(String arg0, String arg1) throws InterruptedException {
        DemoUtils.launchUrl(arg0,arg1);
    }

    @When("User enter Login Credentials  {string} {string}")
    public void userEnterLoginCredentials(String arg0, String arg1) {
        DemoUtils.enterLoginCredentials(arg0,arg1);
    }

    @And("Click on logIn")
    public void clickOnLogIn() {
        CommonPage.WebClick("Login_Button");
    }

    @Then("Validate Dashboard is displayed")
    public void validateDashboardIsDisplayed() {
        DemoUtils.homePageIsDisplayed();
    }

    @And("Quit the browser")
    public void quitTheBrowser() {
        CommonPage.CloseBrowser();
    }
}
