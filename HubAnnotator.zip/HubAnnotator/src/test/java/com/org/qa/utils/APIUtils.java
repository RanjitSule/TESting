package com.org.qa.utils;

import com.org.qa.config.Config;
import io.qameta.allure.Allure;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.json.simple.parser.JSONParser;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import static io.restassured.RestAssured.*;


public class APIUtils extends Config {
    static Response response;
    public APIUtils() throws IOException {
    }

    //Method Name : post
    //Description : This method is common method for post request with request payload
    public static Response post(String baseUrl, Map<String, String> requestHeaders, FileInputStream body) {
        try {
            return given().relaxedHTTPSValidation().baseUri(baseUrl).contentType("application/json").headers(requestHeaders).body(body).post();

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Method Name: delete
    //Description: This method is common method for delete request
    public static Response delete(String baseUrl) {
        try {
            urlEncodingEnabled = false;
            return given().contentType(ContentType.JSON).delete(baseUrl);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Method Name: put
    //Description: This method is common method for put request
    public static Response put(String baseUrl) {
        try {
            urlEncodingEnabled = false;
            return given().contentType(ContentType.JSON).put(baseUrl);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Method Name: postWithQueryPArameter
    //Description: This method is common method for post request with query params
    public static Response postWithQueryPArameter(String baseUrl, String uri, String params, Map<String, String> requestHeaders, String body) {
        try {
            return given().relaxedHTTPSValidation().baseUri(baseUrl).contentType("application/json")
                    .queryParam(params).headers(requestHeaders).body(body).post();

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Method Name: get
    //Description: This method is common method for get request
    public static Response get(String baseUrl, String uri, Map<String, String> requestheaders) {
        try {
            return given().relaxedHTTPSValidation().baseUri(baseUrl).contentType("application/json").headers(requestheaders).get(uri);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Method Name: getUrl
    //Description: This method is common method for getting the url
    public static Response getUrl(String baseUrl, String xApiKey, String XRestAssuredWith) {
        try {
            urlEncodingEnabled = false;
            Map<String, String> requestHeaders = new HashMap<>();
            requestHeaders.put("x-api-key", xApiKey);
            requestHeaders.put("X-Requested-With", XRestAssuredWith);
            return given().relaxedHTTPSValidation().headers(requestHeaders).get(baseUrl);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Method Name: getUrlWithAuth
    //Description: This method is common method for getting url with authorization
    public static Response getUrlWithAuth(String baseUrl) {
        String strToken = "";
        try {
            return given().relaxedHTTPSValidation().

                    headers("Authorization", "Bearer", strToken).get(baseUrl);

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Method Name: postWithAuth
    //Description: This method is common method for post request with authorization
    public static Response postWithAuth(String baseUrl, String uri, String body) {
        try {
            String sToken = "";
            return given().relaxedHTTPSValidation().baseUri(baseUrl).contentType("application/json")
                    .headers("Authorization", sToken).body(body).post();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Method Name: getWithQueryParams
    //Description: This method is common method for get request with query params
    public static Response getWithQueryParams(String baseUrl, String uri, String params, Map<String, String> requestheaders) {
        try {
            useRelaxedHTTPSValidation();
            return given().relaxedHTTPSValidation().baseUri(baseUrl)
                    .queryParam(params).headers(requestheaders).get(uri);

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Method Name: getJSONObject
    //Description: This method returns JSON object
    public static org.json.simple.JSONObject getJSONObject(String filepath,String FileName) {
        try{
            JSONParser jsonParser =new JSONParser();
            FileReader reader= new FileReader(filepath +FileName);
            Object obj = jsonParser.parse(reader);
            return (org.json.simple.JSONObject)obj;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    //Method Name: checkStatusCode
    //Description: This method is common method to checks the status code
    public static void checkStatusCode(int statuscode)
    {
        try{
            switch(statuscode)
            {
                case HttpStatus.SC_OK:
                    break;
                case HttpStatus.SC_UNAUTHORIZED:
                    break;
                case HttpStatus.SC_ACCEPTED:
            }

        }
        catch(Exception e)
        {
            e.printStackTrace();

        }
    }

    //Method Name: Put
    //Description: This method is common method for pur request
    public static Response Put(Map header,InputStream file, String URL){
        try {
            response = RestAssured.given().contentType(ContentType.JSON).headers(header).body(file).put(URL);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return response;
    }

    //Method Name: SchemaValidation
    //Description: This method is common method for json schema validation
    public static void SchemaValidation(InputStream schema){
        try {
            response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(schema));
            Allure.step("Schema Validation is Done Successfully!!!");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
