package com.org.qa.utils;

import com.org.qa.utils.constants.Constants;
import io.qameta.allure.Allure;
import io.qameta.allure.model.Status;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

import static com.org.qa.utils.FileUtil.captureScreenShot;
import static org.apache.poi.ss.usermodel.CellType.*;

public class ExcelReader {

    /* Application: Excel Function
     * Method Name: getExportedSheet
     * Description: This method is used to get the latest sheet downloaded from the application
     * Parameters: NA
     * Author: Aastha Uppal
     */
    public static String getExportedSheet() {
        String exportedSheet = null;
        try {
            System.out.println("Sys download path: " + Constants.systemDownloadsPath);
            File folder = new File(Constants.systemDownloadsPath);
            File[] files = folder.listFiles();
            if (folder.listFiles().length>0){
                Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                exportedSheet = Constants.systemDownloadsPath + files[0].getName();
                System.out.println("Old:" + exportedSheet);
                String dirPath = System.getProperty("user.dir") + Constants.testArtifactDownloadsPath;
                FileUtil.copyFile(exportedSheet, dirPath);
                exportedSheet = dirPath + files[0].getName();
                System.out.println("New:" + exportedSheet);
            } else {
                Allure.step("Exported file not present in the folder", Status. FAILED);
                Assert.fail();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return exportedSheet;
    }

    /* Application: Excel Function
     * Method Name: deleteLastExportedSheet From Downloads
     * Description: This method is used to delete the latest sheet downloaded
     * Parameters: NA
     * Author : Aastha Uppal
     */
    public static String deleteLastExportedSheetFromDownloads() {
        String exportedSheet = null;
        try {
            String path = System.getProperty("user.dir") + Constants.testArtifactDownloadsPath;
            File folder = new File(path);
            File[] files = folder.listFiles();
            if (folder.listFiles().length > 0) {
                Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_REVERSE);
                exportedSheet = path + files[0].getName();
                if (files[0].delete()) {
                }
                System.out.println(files[0].getName() + " File Deleted");
            } else {
                Allure.step("Exported file not present in the folder", Status.FAILED);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return exportedSheet;
    }
































    /* Application: Excel Function
     * Method Name: getSheetColumnNames
     * Description: This method is used to get column names of the exported sheet
     * Parameters: rowNo
     * Author : Aastha Uppal
     */
    public static ArrayList getSheetColumnNames (int rowNo) {
        java.util.List<String> colNames = new ArrayList<String>();
        try {
            String path = ExcelReader.getExportedSheet();
            File folder = new File(path);
            if (folder.exists()) {

                FileInputStream fis = new FileInputStream(path);
                XSSFWorkbook workbook = new XSSFWorkbook(fis);
                XSSFSheet sheet = workbook.getSheetAt(0);
                XSSFRow row = sheet.getRow(rowNo);
                System.out.println("rowNo" + rowNo);
                for (int i = 0; i < row.getLastCellNum(); i++) {
                    colNames.add(row.getCell(i).getStringCellValue().trim());
                }
                fis.close();
                deleteLastExportedSheetFromDownloads();
            } else {
                Allure.step("Exported file not present in the folder", Status. FAILED);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (ArrayList) colNames;
    }

    /* Application: Excel Function
     * Method Name: getSheet ColumnNames
     * Description: This method is used to get column names of the exported sheet
     * Parameters: Sheet
     * Author : Aastha Uppal
     */
    public static ArrayList getSheetColumnNames (String Sheet) {
        java.util.List<String> colNames = new ArrayList<>();
        try {
            String path = getExportedSheet();
            File folder = new File(path);
            if (folder.exists()) {

                FileInputStream fis = new FileInputStream(path);
                XSSFWorkbook workbook = new XSSFWorkbook(fis);
                XSSFSheet sheet = workbook.getSheet (Sheet);

                XSSFRow row = sheet.getRow(0);
                for (int i = 0; i < row.getLastCellNum(); i++) {
                    colNames.add(row.getCell(i).getStringCellValue().trim());
                    System.out.println(row.getCell(i).getStringCellValue());
                }
                fis.close();
            } else {
                Allure.step("Exported file not present in the folder", Status. FAILED);
                Assert.fail();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (ArrayList) colNames;
    }

    /* Application: Excel Function
    * Method Name: ValidateExcelSheetName
    * Description: This method is used to Validate Excel Sheet Name
    * Parameters: NA
    * Author : Aastha Uppal
    */
    public static void ValidateExcelSheetName(String SheetName) throws Exception {
    try {

        String path = getExportedSheet();
        File folder = new File(path);
        if (folder.exists()) {

            FileInputStream fis = new FileInputStream(path);
            XSSFWorkbook workbook = new XSSFWorkbook(fis);
            if (workbook.getNumberOfSheets() != 0) {
                for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                    if (SheetName.equals(workbook.getSheetName(i))) {
                        Allure.step("Sheet name '" + SheetName + "' exist in Excel file", Status. PASSED);
                        break;
                    }
                    if (i == workbook.getNumberOfSheets()) {
                        Allure.step("Sheet name '" + SheetName + "' not exist in Excel file", Status. PASSED);
                    }
                }
            }
        }
    } catch (Exception e) {
        Allure.step("User not able to Upload file", Status.FAILED);
        e.printStackTrace();
        Assert.fail();
    }
    }

    public static String getDownloadedFileName() {
        String downloadedFileName = null;
        try {
            String path = System.getProperty("user.dir")+Constants.testArtifactDownloadsPath;
            File folder = new File(path);

            File[] files = folder.listFiles();
            if (folder.listFiles().length>0) {
                Arrays.sort(files, LastModifiedFileComparator. LASTMODIFIED_REVERSE);
                downloadedFileName=path+files[0].getName();
            }else {
                Allure.step("Downloaded file not present in the folder", Status. FAILED);}
        }catch(Exception e) {
            e.printStackTrace();
        }return downloadedFileName;
    }

    public String path;
    public static FileInputStream fis = null;
    public static FileOutputStream fileOut = null;
    public static XSSFWorkbook workbook = null;
    public static XSSFSheet sheet = null;
    public static XSSFRow row = null;
    public static Cell cell = null;

    public ExcelReader(String path) {
        this.path = path;
        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            sheet = workbook.getSheetAt(0);
            System.out.println(sheet);
            fis.close();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public int getRowCount(String sheetName) {
        int index = workbook.getSheetIndex(sheetName);
        if (index ==-1) return 0;
        else {
            sheet = workbook.getSheetAt(index);
            int number = sheet.getLastRowNum() + 1;
            return number;
        }
    }

    public boolean setCellData(String sheetName, String colName, int rowNum, String data) throws InterruptedException {
        try {
            fis = new FileInputStream(path);
            workbook = new XSSFWorkbook(fis);
            if (rowNum <= 0) return false;
            int index = workbook.getSheetIndex(sheetName);
            int colNum = -1;
            if (index == -1) return false;
            sheet = workbook.getSheetAt(index);
            row = sheet.getRow(0);
            for (int i = 0; i < row.getLastCellNum(); i++) {

                if (row.getCell(i).getStringCellValue().trim().equals(colName)) colNum = i;
            }
            if (colNum == -1) return false;
            sheet.autoSizeColumn(colNum);
            row = sheet.getRow(rowNum - 1);
            if (row == null) row = sheet.createRow(rowNum-1);
            cell = row.getCell(colNum);
            if (cell == null)
                cell = row.createCell(colNum);
            cell.setCellValue(data);
            fileOut = new FileOutputStream(path);
            workbook.write(fileOut);
            // workbook.close();
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                fis.close();
                Thread.sleep(1000);
            } catch (IOException io) {
                io.printStackTrace();
            }
        }
        return true;
    }





    public String getCellData (String sheetName, String colName, int rowNum) {
        try {
            System.out.println(sheetName);
            System.out.println(rowNum);
            if (rowNum <= 0) return "";
            int index = workbook.getSheetIndex(sheetName);
            System.out.println("SheetIndex:" + index);
            System.out.println("SheetName in Excel Reader is:" + sheetName);
            int col_Num = -1;
            if (index == -1) return "";

            sheet = workbook.getSheetAt(index);
            row = sheet.getRow(0);
            for (int i = 0; i < row.getLastCellNum(); i++) {
                if (row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
                    col_Num = i;
            }

            if (col_Num == -1)
                return "";

            sheet = workbook.getSheetAt(index);
            row = sheet.getRow(rowNum - 1);
            if (row == null) return "";
            cell = row.getCell(col_Num);

            if (cell == null) return "";

            if (cell.getCellType() == STRING) {
                return cell.getStringCellValue();
            } else if (cell.getCellType() == NUMERIC || cell.getCellType() == FORMULA) {

                String cellText = String.valueOf(cell.getNumericCellValue());
                if (DateUtil.isCellDateFormatted(cell)) {
                    // format in form of M/D/YY
                    double d = cell.getNumericCellValue();

                    Calendar cal = Calendar.getInstance();
                    cal.setTime(DateUtil.getJavaDate(d));
                    cellText = (String.valueOf(cal.get(Calendar.YEAR))).substring(2);

                    cellText = cal.get(Calendar.DAY_OF_MONTH) + "/" +
                            cal.get(Calendar.MONTH) + 1 + "/" +
                            cellText;
                }
                return cellText;
            } else if (cell.getCellType() == BLANK)
                return "";
            else
                return String.valueOf(cell.getBooleanCellValue());

        } catch (Exception e) {
            e.printStackTrace();
            return "row" + rowNum + " or column " + colName + " does not exist in xls";
        }
    }
    /* Method Name: replace Corresponding Value
    * Description: This method is used to read the value from one cell and replace that value with the
    adjacent value
    * Parameters
    * Author : Monish
    * Date : 16/10/2023
    */
    static String supplierShortID;
    public static String replaceCorrespondingValue(String filePathShortID, String shortID) {
        try {

            File excelPath = new File(filePathShortID);
            FileInputStream filePath = new FileInputStream (excelPath);

            XSSFWorkbook workbook = new XSSFWorkbook(filePath);
            XSSFSheet sheetName = workbook.getSheet("ShortID");

            //in this loop we are reading the short-id
            int totalRows = sheetName.getLastRowNum();
            System.out.println("totalRows: "+totalRows);
            for (int r=1; r<=totalRows;r++) {
                Row row = sheetName.getRow(r);
                System.out.println("r="+r);
                Cell shortIDCell = row.getCell(0);
                shortIDCell.setCellType(STRING);
                String supplierShortID1=shortIDCell.getStringCellValue();
                supplierShortID = supplierShortID1.trim();
                System.out.println("supplierShortID="+supplierShortID);
                System.out.println("shortID="+shortID);

                if(shortID.equals(supplierShortID))
                {
                    System.out.println("equal");
                    Cell fullNameCell=row.getCell(1);
                    fullNameCell.setCellType(STRING);
                    supplierShortID=fullNameCell.getStringCellValue();
                    System.out.println("in if - supplierShortID="+supplierShortID);
                    return supplierShortID;
                }else{
                    System.out.println("in else - not the wanted supplierShortID="+supplierShortID);
                    supplierShortID = null;
                }

            }

            if(supplierShortID==null){
                Allure.step("Full Name of Internal Contact is not present in Short-ID Excel", Status. FAILED);
                Assert.fail();
            }

        } catch (Exception e) {
            Allure.step("Full name of Internal Contact not present", Status. FAILED);
            e.printStackTrace();
            Assert.fail();
        }
        return null;
    }
    /* Application: Excel Function
    * Method Name: getSheet ColumnNames And Storeltin HashMap
    * Description: This method is used to get column names of the exported sheet and store it in HaspMap
    * Parameters: Row1, Row2
    * Author: Jeevan Shetty S
    */
    public static HashMap getSheetColumnNamesAndStoreltinHashMap(int Row1, int Row2) throws Exception {
        Map Excelmap = new HashMap();
        try {
            String path = ExcelReader.getDownloadedFileName();
            File folder = new File(path);
            if (folder.exists()) {
                FileInputStream fis = new FileInputStream(path);
                XSSFWorkbook workbook = new XSSFWorkbook(fis);
                XSSFSheet sheet = workbook.getSheetAt(0);
                Row rows = sheet.getRow(Row2);
                for (int i = 0; i < rows.getLastCellNum(); i++) {
                    cell = rows.getCell(i);
                    String ColumnNames = sheet.getRow(Row1).getCell(i).getStringCellValue().trim();
                    System.out.println("Column names " + ColumnNames);
                    //checking for celltype
                    if (cell.getCellType() == BOOLEAN) {
                        String ColumnValues =
                                String.valueOf(sheet.getRow(Row2).getCell(i).getBooleanCellValue()).trim();
                        System.out.println("Column Values" + ColumnValues); Excelmap.put(ColumnNames, ColumnValues);
                    } else if (cell.getCellType() == STRING) {
                        String ColumnValues = sheet.getRow(Row2).getCell(i).getStringCellValue().trim();
                        System.out.println("Column Values" + ColumnValues);
                        Excelmap.put(ColumnNames, ColumnValues);
                    } else if (cell.getCellType() == NUMERIC || cell.getCellType() == FORMULA || cell.getCellType () == BLANK) {
                        double ColumnValues = sheet.getRow(Row2).getCell(i).getNumericCellValue();
                        System.out.println("Column Values" + ColumnValues);
                        Excelmap.put(ColumnNames, ColumnValues);
                    }
                }
                fis.close();
                // deleteLastExportedSheetFrom Downloads();
            } else {
                Allure.step("Exported file not present in the folder", Status. FAILED);
                captureScreenShot("Exported file not present in the folder ", "Fail");
                Assert.fail();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (HashMap) Excelmap;
    }
    /* Application: PROPLAN
    * Method Name: getSheetAllColumnNames
    * Description: This Method Is Used To Get Sheet All Column Names In Download Excel File
    * Parameters: int rowNo
    * Author: Sule, Ranjit
    * Date : 02/19/2024
    */
    public static ArrayList getSheetAllColumnNames(int rowNo) {
        java.util.List<String> colNames = new ArrayList<>();
        try {
            String path = ExcelReader.getDownloadedFileName();
            File folder = new File(path);
            if (folder.exists()) {

                FileInputStream fis = new FileInputStream(path);
                XSSFWorkbook workbook = new XSSFWorkbook(fis);
                XSSFSheet sheet = workbook.getSheetAt(0);
                XSSFRow row = sheet.getRow(rowNo);
                System.out.println("rowNo"+rowNo);
                for(int i=0;i<row.getLastCellNum();i++){
                    colNames.add(row.getCell(i).getStringCellValue().trim());
                }
                fis.close();
            }else {Allure.step("Exported file not present in the folder", Status.FAILED);}
        }catch(Exception e) {
            e.printStackTrace();
        }return (ArrayList) colNames;
    }
    /* Application: PROPLAN
    * Method Name: EditDown Excel FileDataAndUploadInMySBtable
    * Description: This Method Is Used To Get Sheet Values In Boolean For Excel File
    * Parameters: int rowNo
    * Author : Sule, Ranjit
    * Date : 02/19/2024
    */
    public static ArrayList getSheetValuesBoolean(int rowNo) {
        ArrayList<Boolean> booleanList = new ArrayList<>();
    try {
        String path= ExcelReader.getDownloadedFileName();
        File folder = new File(path);
        if (folder.exists()) {

            FileInputStream fis = new FileInputStream(path);
            XSSFWorkbook workbook = new XSSFWorkbook(fis);
            XSSFSheet sheet = workbook.getSheetAt(0);
            XSSFRow row = sheet.getRow(rowNo);
            for(int i=0;i<row.getLastCellNum();i++) {
                boolean isLocked = row.getCell(i).getCellStyle().getLocked();
                boolean isWritable = !(isLocked);
                booleanList.add(isWritable);
            }
            fis.close();
            }else {Allure.step("Exported file not present in the folder", Status. FAILED);}
        }catch(Exception e) {
            e.printStackTrace();
        }return (ArrayList) booleanList;
    }
    /* Application: PROPLAN
    * Method Name: Edit Down Excel FileDataAndUploadinMySBtable
    * Description: This Method Is Used To Set All Type Cell Data In Excel File
    * Parameters: setAllTypeCellData
    * Author: Sule, Ranjit
    * Date : 02/19/2024
    */
    public static boolean setAllTypeCellData (String sheetName, String colName, int rowNum, String data) throws InterruptedException {
    try {
        String path = ExcelReader.getDownloadedFileName();
        fis = new FileInputStream(path);
        workbook = new XSSFWorkbook(fis);
        if (rowNum <= 0) return false;
        int index = workbook.getSheetIndex(sheetName);
        int colNum = -1;
        if (index == -1) return false;
        sheet = workbook.getSheetAt(index);
        row = sheet.getRow(0);
        for (int i = 0; i < row.getLastCellNum(); i++) {
            if (row.getCell(i).getStringCellValue().trim().equals(colName)) colNum = i;
        }
        if (colNum == -1) return false;
        sheet.autoSizeColumn (colNum);
        row = sheet.getRow(rowNum - 1);
        if (row == null) row = sheet.createRow(rowNum - 1);
        cell = row.getCell(colNum);
        if (cell == null)
            cell = row.createCell(colNum);
        String oldValue="";
        if (cell.getCellType() == BOOLEAN) {
            oldValue = String.valueOf(cell.getBooleanCellValue());
            cell.setCellValue(Boolean.parseBoolean(data));
        } else if (cell.getCellType() == NUMERIC) {
            oldValue = String.valueOf(cell.getNumericCellValue());
            cell.setCellValue(data);
        }else {
            oldValue=cell.getStringCellValue();
            cell.setCellValue(data);
        }
        System.out.println(oldValue+" Old value Change to New Value:"+data);
        fileOut = new FileOutputStream(path);
        workbook.write(fileOut);
        fileOut.close();
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    } finally {
        try {
            fis.close();
            Thread.sleep(1000);
        } catch (IOException io) {
            io.printStackTrace();
        }
    }
        return true;
    }

    /* Application: PROPLAN
    Method Name: getSheetAllColumnNamesAndStoreltin HashMap
    * Description: This Method Is Used To Get Sheet All Column Names And Store It In HashMap
    Parameters: int Row1, int Row2, int Excel Hederlength
    Author:Sule, Ranjit
    Date : 02/26/2024
    */
    public static HashMap getSheetAllColumnNamesAndStoreltInHashMap(int Row1, int Row2, int  ExcelHederlength) throws Exception {
        Map Excelmap = new HashMap();
        try {
            String path = ExcelReader.getDownloadedFileName();
            File folder = new File(path);
            if (folder.exists()) {
                FileInputStream fis = new FileInputStream(path);
                XSSFWorkbook workbook = new XSSFWorkbook(fis);
                XSSFSheet sheet = workbook.getSheetAt(0);
                Row rows = sheet.getRow(Row2);
                int valuerow = ExcelHederlength;
                for (int i = 0; i < valuerow; i++) {
                    cell = rows.getCell(i);
                    String ColumnNames = sheet.getRow(Row1).getCell(i).getStringCellValue().trim();
                    System.out.println("Column names" + ColumnNames);
                    //checking for celltype
                    if (cell.getCellType() == BOOLEAN) {
                        String ColumnValues =
                                String.valueOf(sheet.getRow(Row2).getCell(i).getBooleanCellValue()).trim();
                        System.out.println("Column Values" + ColumnValues);
                        Excelmap.put(ColumnNames, ColumnValues);
                    } else if (cell.getCellType() == STRING) {
                        String ColumnValues = sheet.getRow(Row2).getCell(i).getStringCellValue().trim();
                        System.out.println("Column Values" + ColumnValues);
                        Excelmap.put(ColumnNames, ColumnValues);
                    } else if (cell.getCellType() == NUMERIC || cell.getCellType() == FORMULA ||
                            cell.getCellType () == BLANK) {
                        double ColumnValues = sheet.getRow (Row2).getCell(i).getNumericCellValue();
                        System.out.println("Column Values" + ColumnValues);
                        Excelmap.put(ColumnNames, ColumnValues);
                    }
                }
                fis.close();
            } else {
                Allure.step("Exported file not present in the folder", Status. FAILED); captureScreenShot("Exported file not present in the folder ", "Fail"); Assert.fail();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (HashMap) Excelmap;
    }


}
