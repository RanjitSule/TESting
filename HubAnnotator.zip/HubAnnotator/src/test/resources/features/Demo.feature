Feature: SauceLabs Login functionality check
  @TC001
  Scenario Outline: Verify User can Login
    Given User open application "<FileName>" "<Scenario>"
    When User enter Login Credentials  "<FileName>" "<Scenario>"
    And Click on logIn
    Then Validate Dashboard is displayed
    And Quit the browser
    Examples:
      | FileName | Scenario |
      | testData | TC001    |